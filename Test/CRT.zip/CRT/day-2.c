/* #include<stdio.h>
int main(){
    int a,b,c,num1;
    printf("Enter the value of A & B");
    scanf("%d%d",&a,&b);
    printf("Enter 1 for add,2 for sub,3 for mul,4 for mod div");
    scanf("%d",&num1);
    switch(num1){
        case 1:
            c=a+b;
            printf("Sum of the numbers is:%d",c);
            break;
        case 2:
            c=a-b;
            printf("Subtraction of the numbers is:%d",c);
            break;
        case 3:
            c=a*b;
            printf("Product of the numbers is:%d",c);
            break;
        case 4:
            c=a%b;
            printf("Mod Division of the numbers is:%d",c);
            break;
        default:
            printf("Choose the correct option of either 1,2,3,4");
    }
} */

/* #include<stdio.h>
int main(){
    int num;
    scanf("%d",&num);
    if(num<=9){
        printf("Digit");
    }
    else{
        printf("Number");
    }
}  */

/* #include<stdio.h>
int main(){
    int i;
    for(i=-2;i<=8;){
        i+=2;
        printf("%d\n",i);
    }
} */
/* #include <stdio.h>

int main() {
    int n, i;
    scanf("%d", &n);
    for(i = 1; i <= n; i++)
        if(i % 2 == 0)
            printf("%d ", i);
    printf("\n");
    for(i = n; i >= 1; i--)
        printf("%d ", i);
    printf("\n");
    for(i = 1; i <= n; i++)
        if(i % 2 == 0)
            printf("%d ", i);
    printf("\n");
    for(i = 1; i <= n; i++)
        if(i % 2 != 0)
            printf("%d ", i);
} */
/* #include<stdio.h>
int main(){
    int var=1;
    while(var<=2){
        printf("%d",var);
    }
} */
/* #include<stdio.h>
int main(){
    char name[100];
    int i,c=0;
    scanf("%s",&name);
        for(i = 0; name[i] != '\0'; i++) {
        if(name[i]=='a' || name[i]=='e' || name[i]=='i' 
        ||name[i]=='o' || name[i]=='u' || name[i]=='A' || 
        name[i]=='E' || name[i]=='I' ||
        name[i]=='O' || name[i]=='U') {
            c++;
        }
    }
    printf("%d",c);
} */
/* #include<stdio.h>
int main(){
    char ch;
    for(ch='A';ch<='Z';ch++){
        printf("%c:%d ",ch,ch);
    }
} */
/* #include <stdio.h>
void main() {
    int n, sum = 0;
    while (scanf("%d", &n) == 1 && n != 0) {
        sum += n;
    }
    printf("%d\n", sum);
} */
/* #include<stdio.h>
int main(){
    int n=10;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=i;j++){
            printf("*");
        }
        printf("\n");
    }
} */