/* #include <stdio.h>
// Print a right-angled triangle pattern of asterisks
int main() {
    int n, i, j;
    scanf("%d", &n);
    for(i = 1; i <= n; i--) {
        for(j = 1; j <= i; j--) {
            printf("*");
        }
        printf("\n");
    }
}
 */
/* #include<stdio.h>
int main(){
    int n;
    printf("Enter the size of the array");
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++){
        printf("Enter the element %d:",i+1);
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<n;i++){
        printf("%d\n",arr[i]);
    }
} */
/* #include <stdio.h>
int main(){
    int n,i;
    int sales[100];
    int total=0,even=0;
    printf("Enter the size of array");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        printf("Enter the element %d:",i+1);
        scanf("%d",&sales[i]);
        total+=sales[i];
        if(i%2==0){
            even+=sales[i];
        }
    }
    printf("total sales:%d\n", total);
    printf("sum of even numbers:%d\n", even);
} */
/* #include<stdio.h>
int main(){
    int n,i;
    printf("Enter the size of the array:");
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++){
        printf("Enter the element %d:",i+1);
        scanf("%d",&arr[i]);
    }
    int max=arr[0];
    for(i=1;i<n;i++){
        if(arr[i]>max){
            max=arr[i];
        }
    }
    int min=arr[0];
    for(i=1;i<n;i++){
        if(arr[i]<min){
            min=arr[i];
        }
    }
    printf("The largest element is:%d\n",max);
    printf("The smallest element is:%d\n",min);
} */
