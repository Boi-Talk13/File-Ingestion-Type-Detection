/* #include <stdio.h>

int main() {
    int eid;
    float salary;
    printf("Enter the Employee ID");
    scanf("%d", &eid);
    printf("Enter the Salary");
        scanf("%f",&salary);
    printf("Employee ID: %d\n", eid);
    printf("Salary: %.2f\n", salary);
}
#include<stdio.h>
int main(){
    long num;
    printf("Enter the Mobile Number: ");
    scanf("%ld",&num);
    printf("Mobile Number:%ld",num);
}
 #include<stdio.h>
 void main(){
     int sub1,sub2,sub3;
     float avg;
     printf("Enter the Marks of subjects:\n");
     scanf("%d%d%d",&sub1,&sub2,&sub3);
     avg=(sub1+sub2+sub3)/3.0;
     printf("Avarage marks in Each Subject:%.2f",avg);
 }
#include<stdio.h>
void main(){
    int unit1,unit2,final;
    scanf("%d%d",&unit1,&unit2);
    final=unit2-unit1;
    printf("Units Consumed:%d",final);
}
#include <stdio.h>

int main()
{
    int hw=150,hwork,salary;
    scanf("%d",&hwork);
    salary=hw*hwork;
    printf("Daily Salary:%d",salary);
    return 0;
}
#include <stdio.h>

int main()
{
    float f,c;
    printf("Enter Celcius");
    scanf("%f",&c);
    f=(c*9/5)+32;
    printf("Converted to faranite:%.1f",f);
}
#include <stdio.h>

int main()
{
    float f,c;
    printf("Enter Celcius");
    scanf("%f",&c);
    f=(c*9/5)+32;
    printf("Converted to faranite:%.1f",f);
}
#include <stdio.h>

int main()
{
    int a;
    a=50;
    printf("%d",++a);
}
#include <stdio.h>
int main()
{
    int num;
    scanf("%d", &num);
    printf("%s", (num % 2 == 0) ? "Even" : "Odd");
    return 0;
}
#include <stdio.h>
int main()
{
    int salary;
    scanf("%d",&salary);
    salary=salary+2000;
    printf("Salary:%d",salary);
}
#include <stdio.h>

int main()
{
    int username,pwd;
    printf("username:\n");
    scanf("%d",&username);
    printf("Password:\n");
    scanf("%d",&pwd);
    if(username==1234 && pwd==9999){
        printf("Login Sucess");
    }
    else{
        printf("Login Failed");
    }
}
#include <stdio.h>

int main()
{
    int ticket;
    printf("Tickets\n");
    scanf("%d",&ticket);
    printf("Rem:%d\n",--ticket);
}
#include <stdio.h>
int main()
{
    int age, smoker;
    scanf("%d %d",&age,&smoker);
    if(age>=18)
    {
        if(smoker==1)
            printf("6000");
        else
            printf("4000");
    }
    else
    {
        printf("Not eligible");
    }
}

#include <stdio.h>

int main()
{
    int user,admin;
    scanf("%d%d",&user,&admin);
    if((user & admin)!=0){
        printf("Access Granted");
    }
    else{
        printf("Denaied");
    }
}*/
/* #include <stdio.h>
int main()
{
    int bill_t,discount,bill_d;
    printf("Enter the total amount of your bill:\n");
    scanf("%d",&bill_t);
    if(bill_t>=5000){
        discount=(bill_t*10)/100;
        bill_d=bill_t-discount;
        printf("Total bill after discount:%d\n",bill_d);
    }
    else{
        printf("no discount");
    }
} */