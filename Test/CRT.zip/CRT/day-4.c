/* #include <stdio.h>
int main() {
    int a[100], n, i, j, k;
    printf("Enter size of array: ");
    scanf("%d", &n);
    printf("Enter %d elements:\n", n);
    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for(i = 0; i < n; i++) {
        for(j = i + 1; j < n; j++) {
            if(a[i] == a[j]) {
                for(k = j; k < n - 1; k++)
                    a[k] = a[k + 1];
                n--; 
                j--;  
            }
        }
    }
    printf("Array after removing duplicates:\n");
    for(i = 0; i < n; i++)
        printf("%d ", a[i]);
    return 0;
} */

/* #include <stdio.h>
int main() {
    int a[100], n, key, i, found = 0;
    printf("Enter size of array: ");
    scanf("%d", &n);
    printf("Enter %d elements:\n", n);
    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter element to search: ");
    scanf("%d", &key);
    for(i = 0; i < n; i++) {
        if(a[i] == key) {
            printf("Element found at index %d\n", i);
            found = 1;
            break;
        }
    }
    if(!found)
        printf("Element not found\n");
    return 0;
} */

/* #include<stdio.h>
int main(){
    int arr[100][100],rows,cols;
    printf("Enter number of rows and columns");
    scanf("%d%d",&rows,&cols);
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            scanf("%d",&arr[i][j]);
        }
    }
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            printf("%d ",arr[i][j]);
        }
        printf("\n");
    }
} */
/* #include<stdio.h>
int main(){
    int arr[3][3],i,j;
    printf("Enter the elements of the matrix\n");
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            scanf("%d",&arr[i][j]);
        }
    }
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            printf("%d ",arr[i][j]);
        }
        printf("\n");
    }
    // Sum of rows
    printf("Sum of rows:\n");
    for(i=0;i<3;i++){
        int rowSum = 0;
        for(j=0;j<3;j++){
            rowSum += arr[i][j];
        }
        printf("Row %d: %d\n", i+1, rowSum);
    }
    // Sum of columns
    printf("Sum of columns:\n");
    for(j=0;j<3;j++){
        int colSum = 0;
        for(i=0;i<3;i++){
            colSum += arr[i][j];
        }
        printf("Column %d: %d\n", j+1, colSum);
    }
   for(j=0;j<3;j++){
        for(i=0;i<3;i++){
            printf("%d ",arr[i][j]);
        }
        printf("\n");
    } 
   printf("Row Sum:\n");
   for(int i=0;i<=3;i++){
    int sum=0;
    for(j=0;j<=3;j++){
        sum+=arr[i][j];
    }
    printf("Sum of row %d is %d\n",sum);
   }
} */
/* #include<stdio.h>
int main(){
    int i,j;
    int arr1[3][3]={
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };
    printf("Row wise order using while loop\n");
    i=0;
    while(i<3){
        j=0;
        while(j<3){
            printf("%d ",arr1[i][j]);
            j++;
        }
        printf("\n");
        i++;
    }
    printf("Col wise order using while loop\n");
    j=0;
    while(j<3){
        i=0;
        while(i<3){
            printf("%d ",arr1[i][j]);
            i++;
        }
        printf("\n");
        j++;
    }
} */
#include<stdio.h>
int main(){
    int i,j;
    int arr1[3][3]={
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };
    i=0;
    while(i>=-1){
        j=2;
        while(j>=0){
            printf("%d ",arr1[i][j]);
            j--;
        }
        printf("\n");
        i--;
    }
    printf(" \n");
    j=0;
    while(j<3){
        i=0;
        while(i<3){
            printf("%d ",arr1[i][j]);
            i++;
        }
        printf("\n");
        j++;
    }
}